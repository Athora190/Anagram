package com.example.databaseactivity;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RowsAdapter extends RecyclerView.Adapter<RowsAdapter.ViewHolder> {

    private ArrayList<Row> dataset;

    public RowsAdapter(ArrayList<Row> rows, Context c) {
        dataset = rows;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView textViewColumn1, textViewColumn2, textViewColumn3;

        public ViewHolder(View itemView) {
            super(itemView);
            textViewColumn1 = (TextView) itemView.findViewById(R.id.textView1);
            textViewColumn2 = (TextView) itemView.findViewById(R.id.textView2);
            textViewColumn3 = (TextView) itemView.findViewById(R.id.textView3);
        }
    }

    @Override
    public RowsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewtype) {
        Context context = parent.getContext();
        LayoutInflater inflater = LayoutInflater.from(context);

        View rowView = inflater.inflate(R.layout.row_layout, parent, false);
        ViewHolder viewHolder = new ViewHolder(rowView);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RowsAdapter.ViewHolder viewHolder, int position) {
        Row row = dataset.get(position);

        viewHolder.textViewColumn1.setText(row.column1);
        viewHolder.textViewColumn2.setText(row.column2);
        viewHolder.textViewColumn3.setText(row.column3);
    }

    @Override
    public int getItemCount() {
        return dataset.size();
    }
}
