package com.example.databaseactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void ProductByCategory(View view)
    {
        Intent intent = new Intent (this, ResultsActivity.class);
        intent.putExtra("query","SELECT categoryname, productname, unitprice From Products, Categories Where Categories.categoryid = Products.categoryid Order By categoryname;");
        startActivity(intent);
    }

    public void ProductByPrice(View view)
    {
        Intent intent2 = new Intent(this, ResultsActivity.class);
        intent2.putExtra("query","SELECT categoryname, productname, unitprice From Products, Categories Where Categories.categoryid = Products.categoryid Order By unitprice;");
        startActivity(intent2);
    }

    public void ProductUnder25(View view)
    {
        Intent intent3 = new Intent(this, ResultsActivity.class);
        intent3.putExtra("query","SELECT categoryname, productname, unitprice From Products, Categories Where Categories.categoryid = Products.categoryid and unitprice < 25 Order By unitprice;");
        startActivity(intent3);
    }

    public void Product25OrMore(View view)
    {
        Intent intent4 = new Intent(this, ResultsActivity.class);
        intent4.putExtra("query","SELECT categoryname, productname, unitprice From Products, Categories Where Categories.categoryid = Products.categoryid and unitprice >= 25 Order By unitprice;");
        startActivity(intent4);
    }

    public void ProductCount(View view)
    {
        Intent intent5 = new Intent(this, ResultsActivity.class);
        intent5.putExtra("query","Select categoryname, count(productid) From Categories, Products Where Products.categoryid = Categories.CategoryID Group by categoryname;");
        startActivity(intent5);
    }


}
