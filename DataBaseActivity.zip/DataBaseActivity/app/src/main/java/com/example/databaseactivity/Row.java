package com.example.databaseactivity;

public class Row {
    String column1,column2,column3;
    public Row(String c1,String c2,String c3)
    {
        column1 = c1;
        column2 = c2;
        column3 = c3;
    }
}
